import serial
import time

# Khởi tạo kết nối Serial
arduino = serial.Serial(port='/dev/ttyUSB0', baudrate=115200, timeout=1)  # Thay 'COM3' bằng cổng phù hợp
time.sleep(2)  # Chờ Arduino sẵn sàng

def send_values(values):
    # Chuyển danh sách float thành chuỗi, phân cách bằng dấu phẩy
    data = ','.join(f"{value:.2f}" for value in values)
    arduino.write(f"{data}\n".encode())  # Gửi chuỗi xuống Arduino
    print(f"gui: {data}")

def receive_data():
    if arduino.in_waiting > 0:  # Kiểm tra nếu có dữ liệu sẵn
        data = arduino.readline().decode().strip()  # Đọc một dòng và loại bỏ ký tự xuống dòng
        print(f"Nhận: {data}")
        return data
    return None

# Danh sách các giá trị float để gửi
values_to_send = [1.23, 4.56, 7.89, 10.01, 3.14]

while True:
    try:
        send_values(values_to_send)  # Gửi tất cả các giá trị trong một lần
        time.sleep(1)  # Chờ Arduino xử lý
        response = receive_data()  # Nhận phản hồi từ Arduino
        if response:
            print(f"Phản hồi từ Arduino: {response}")
    except KeyboardInterrupt:
        print("Kết thúc chương trình")
    finally:
        arduino.close()

